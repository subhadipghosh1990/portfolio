


$(window).load(function(){
    $(".loader").fadeOut();
});

var txt = $('.newsContent').text();
if (txt.length > 200) {
    $('.newsContent').text(txt.substring(0, 199) + '.....');
}

var sc = $(window).scrollTop();

if (sc > 80) {
    $("header").addClass("downHd");
} else if (sc < 1) {
    $("header").removeClass("downHd");
}




$(".responsiveSideNav").click(function (e) {
    e.preventDefault();
    $(".sidebar").toggleClass("showSideBar");
});




$(window).scroll(function () {
    var sc = $(window).scrollTop();

    if (sc > 80) {
        $("header").addClass("downHd");
    } else if (sc < 1) {
        $("header").removeClass("downHd");
    }

    if (sc < 581) {
        $(".deskTopBanner > .back").css("margin-top", sc * .3 + "px");
    }


});



        






$(".sidebar ul li").click(function (e) {

    e.preventDefault();

    var aa = $(this).index();
    
    $(".fullPageCont").eq(aa).css("z-index", 99999999);
        $(".fullPageCont").eq(aa).siblings().css("z-index", 999999);

    $(".fullPageCont").eq(aa).addClass("otherShow");

    setTimeout(function () {        
        
        $(".fullPageCont").eq(aa).addClass("showCont");
        $(".fullPageCont").eq(aa).siblings().removeClass("showCont otherShow")
    }, 500);

    $("body").css("overflow", "hidden");
    $(".closeTab").addClass("showTabClose");
});

$(".closeTab").click(function (e) {

    e.preventDefault();

    $(this).removeClass("showTabClose");

    $(".fullPageCont").removeClass("showCont");

    setTimeout(function () {
        $(".fullPageCont").removeClass("otherShow");
        $("body").css("overflow", "auto");
    }, 500);

});






$(".thumHolder li").each(function(){
    
    var aa = $(this).index();
    
    $(this).find("a").click(function(e){
        e.preventDefault();     
    });
    
    
    var a,b,c,d,e,f,g,h,i,j,k;
        
        a = $(this).find("img").attr("src");
        b = $(this).find(".name").text();
        c = $(this).find(".age").text();
        d = $(this).find(".country").text();
        e = $(this).find(".league").text();
        f = $(this).find(".scnd").text();
        g = $(this).find(".frst").text();
        h = $(this).find(".height").text();
        i = $(this).find(".gpa").text();
        j = $(this).find(".standout").text();
    
    $(this).click(function(){
        
        $(".thumPLayerResult img").attr("src", a);
        $(".thumPLayerResult .name").text(b);
        $(".thumPLayerResult .age span").text(c);
        $(".thumPLayerResult .country").text("Country- "+d);
        $(".thumPLayerResult .league span").text(e);
        $(".thumPLayerResult .scnd span").text(f);
        $(".thumPLayerResult .frst span").text(g);
        $(".thumPLayerResult .height span").text(h);
        $(".thumPLayerResult .gpa span").text(i);
        $(".thumPLayerResult .standout span").text(j);
        
        $(".modalOverlay").fadeIn();
        
        setTimeout(function(){            
            $(".thumPLayerResult").addClass("showPl");            
        }, 500);
        
    });
    
});


$(".modalOverlay, .closePlayer").click(function(){
    $(".thumPLayerResult").removeClass("showPl");
    $(".SignupformHholder form").fadeOut();
    setTimeout(function(){
        $(".modalOverlay").fadeOut();
    },500);
});


$(".SignupformHholder .closePlayer, .videoPlayer .closePlayer, .signInfrm .closePlayer").click(function(){
    $(this).parent().fadeOut();
});

$("#signIn").click(function(){
    $(".signInfrm").fadeIn();
    $(".modalOverlay").fadeIn();
});


$(".Athletes ul li a").click(function(e){
    e.preventDefault();
});


$(".Athletes ul li").each(function(){
            
            $(this).click(function(){
                var a = $(this).find("img").attr("src");                
                var b = $(this).find("h6").text();                
                var c = $(this).find("h5").text();                
                var d = $(this).find("p").text();
                
                
                $(".selPlayer h2").text(c);
                $(".selPlyrImg img").attr("src", a);
                $(".selPlayer h5").text(b);
                $(".selPlayer p").text(d);

            });
            
});


var winWid = $(window).width();

var slideIn = $(".thumHolder li");
console.log(slideIn.length);
for(var i = 0; i < slideIn.length; i+=27) {
  slideIn.slice(i, i+27).wrapAll("<div class='slide'></div>");
}


if(winWid < 1200){
    
    $(".thumHolder li").unwrap();
    
    for(var i = 0; i < slideIn.length; i+=8) {
      slideIn.slice(i, i+8).wrapAll("<div class='slide'></div>");
    }
}

if(winWid > 992){
    
    $('.newsSec ul').slimscroll({
      height: '100vh'
    });

    $('.vidListHoler').slimscroll({
      height: 'auto'
    });
    
    $(".regisForm form").slimscroll({
      height: 'calc(94vh + 5px)'
    });
    
}

if(winWid < 992){
    $(".sidebar ul li").click(function () {

        $(".sidebar").removeClass("showSideBar");

    });
}

var txt2 = $('.newsBlock p').text();
if (txt2.length > 100) {
    $('.newsBlock p').text(txt2.substring(0, 99) + '.....');
}

if(winWid < 768){    
    $('.newsBlock p').text(txt2.substring(0, 40) + '.....');    
}


//function deskSliReset(){
//    $(".slide").first().addClass("showSlide").removeClass("hideSlide").siblings().addClass("hideSlide").removeClass("showSlide")
//}
//
//deskSliReset();

var current = 0;
$(".slide").eq(current).fadeIn().siblings().fadeOut();

$(".slideNext").click(function(){
    
    if(current < $(".slide").length-1){
        current++;
        $(".slide").eq(current).fadeIn().siblings().fadeOut();
        console.log(current);
    }
    
    else{
        current = 0;
        $(".slide").eq(current).fadeIn().siblings().fadeOut();
        console.log(current);
    }    
    
});


$(".slidePrev").click(function(){
    
    if(current == 0){       
       current = $(".slide").length-1;
        $(".slide").eq(current).fadeIn().siblings().fadeOut();
        console.log(current);
    }
    
    else{
        current--;
        $(".slide").eq(current).fadeIn().siblings().fadeOut();
        console.log(current);
    }        
});


var body = $("html, body");
var tarr = $("footer").offset().top;



$(".conScroll").click(function(){
    
    
    body.stop().animate(
    {scrollTop:tarr}, 1500, 'swing', function() { 
});
    
});



$("nav ul li ul li").each(function(){
    var aa = $(this).index();
    
    $(this).click(function(){
        
        $(".modalOverlay").fadeIn();
        
        $(".SignupformHholder form").eq(aa).fadeIn().siblings().fadeOut();
        
    });
});


$(".Videos .vidListHoler li a").click(function(e){
    e.preventDefault();
});

$(".vidLi li").each(function(){
    
    var aa = $(this).find("iframe").attr("src");
    
    
    
    $(this).click(function(){
        
        $(".modalOverlay").fadeIn();
        
        console.log(aa);
        
        $(".videoPlayer iframe").attr("src", aa + "?rel=0&autoplay=1");
        
        $(".videoPlayer").fadeIn();
        
    });
    
    
});

$(".videoPlayer .closePlayer").click(function(){
    
    var aa = $(".videoPlayer iframe").attr("src");
    
    $(".videoPlayer iframe").attr("src", "");
});


var tot = $(".Videos .secHead ul li").length-1;

$(".vidslideNext").click(function(){
      
    if(current < tot){
        current  ++;
        console.log(current); 
        
        $(".Videos .secHead ul li").eq(current).slideDown().siblings().slideUp();
    }
    else{
        current = 0;
        console.log(current); 
        $(".Videos .secHead ul li").eq(current).slideDown().siblings().slideUp();
    }

});

$(".vidslidePrev").click(function(){
      
    if(current == 0){
        current = tot;
        console.log(current); 
        $(".Videos .secHead ul li").eq(current).slideDown().siblings().slideUp();
    }
    else{
        current--;
        console.log(current); 
        $(".Videos .secHead ul li").eq(current).slideDown().siblings().slideUp();
    }

});



var regsTot = $(".regisSlide").length-1;
function resetRegSlider(){
    $(".regisSlide").eq(current).addClass("currentReg d-flex").removeClass("d-none").siblings().removeClass("d-flex").addClass("d-none");
    console.log(regsTot);
}

resetRegSlider();


setInterval(function(){
    
    
    if(current < regsTot){
        current++;
    }
    else{
        current = 0;
    }
    
    resetRegSlider();
    
    
//    if($(".regisSlide").last().hasClass("currentReg d-flex")){
//        resetRegSlider();
//    }
//    
//    else{
//        
//        $(".currentReg").next().addClass("currentReg d-flex").removeClass("d-none").siblings().removeClass("d-flex").addClass("d-none");
//        
//    }
    
    console.log(current);
    
}, 2000);





















