$(document).ready(function() {
    
	$(".menuToggle").click(function(){
		$("nav").slideToggle();
	});
	
	
	
	//var wrk = [];
		
	$(".workSelector li").first().addClass("activeWrk");
	
	$(".workSelector li").each(function() {
        var a = $(this).index()+1;
		$(this).attr("id", "work" + a);
		
		$(this).find("a").click(function(e){
			e.preventDefault();
		});
		
		var b = $(this).attr("id");
		
		$(this).click(function(){
			
			$("." + b).slideDown().siblings().slideUp();
			
			$(this).addClass("activeWrk").siblings().removeClass("activeWrk");
			
		});

		//var ab = $(this).find("a").text();		
		//wrk.push(ab);
		
    });
	

	
$(".workData .row").first().show().siblings().hide();	
$(".workData .row").each(function() {        
	var a = $(this).index()+1;		
	$(this).addClass("work" + a);		
});

$(".srcFrm form button").click(function(){
	$(this).toggleClass("closeSrch");
	$(this).parent().find("input").toggleClass("wideInput");
	//$(this).parent().find("input").val("");
	//$(this).find("i").toggleClass("fa-search fa-close");
});

//menu backgrund form redirection
var sc = $(window).scrollTop();

if(sc>100){	 
	$("header").addClass("blackOverlay");
	$(".frstShw").hide();
	$(".lastShw").show();
} 

else{
	$("header").removeClass("blackOverlay");
	$(".frstShw").show();
	$(".lastShw").hide();
}
	
	
	
	
});

$(window).scroll(function() {
    
var sc = $(window).scrollTop();

if(sc>50){	 
		$("header").addClass("blackOverlay");
		$(".frstShw").hide();
		$(".lastShw").show();
	} 
	
	else{
		$("header").removeClass("blackOverlay");
		$(".frstShw").show();
		$(".lastShw").hide();
	}
	
});


//angular part
var firstApp = angular.module("profiles", []);
firstApp.controller("searchProfiles", function($scope) {

  $scope.records = [
    {
      "Name" : "Alfreds Futterkiste",
		"Country" : "Germany",
		"img" : "images/p1.jpg",
		"dob" : "24.05.1990",
		"abt" : "On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de distractions, et empêche de se concentrer sur la mise en page elle-même. "
    },
    {
      "Name" : "Berglunds snabbköp",
      "Country" : "Sweden",
	  "img" : "images/p2.jpg",
	  "dob" : "22.01.1980",
		"abt" : "On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de distractions, et empêche de se concentrer sur la mise en page elle-même. "
    },
    {
      "Name" : "Centro Moctezuma",
      "Country" : "Mexico",
	  "img" : "images/p3.jpg",
	  "dob" : "15.09.1975",
		"abt" : "On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de distractions, et empêche de se concentrer sur la mise en page elle-même. "
    },
    {
      "Name" : "Ernst Handel",
      "Country" : "Austria",
	  "img" : "images/p4.jpg",
	  "dob" : "21.05.1980",
		"abt" : "On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de distractions, et empêche de se concentrer sur la mise en page elle-même. "
    },
	{
      "Name" : "Jack Hammond",
      "Country" : "Belarus",
	  "img" : "images/p5.jpg",
	  "dob" : "25.08.1995",
		"abt" : "On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de distractions, et empêche de se concentrer sur la mise en page elle-même. "
    },
	{
      "Name" : "William Thomson",
      "Country" : "England",
	  "img" : "images/p6.jpg",
	  "dob" : "24.05.1990",
		"abt" : "On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de distractions, et empêche de se concentrer sur la mise en page elle-même. "
    }
  ];
  
  $scope.resetit = function(){		
		$scope.searchFor.Name = "";		
	};
});
