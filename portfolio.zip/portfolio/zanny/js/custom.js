
$(window).load(function() {
    $(".loader").fadeOut();
});


$(document).ready(function() {
	
	//PARRALEX
	var ypos,banner;
	function par() {
		banner = document.getElementById("par");
		ypos = window.pageYOffset;
		banner.style.top = ypos * .3 + 'px';
	}
	window.addEventListener('scroll', par);
	
	//$(".down_tree").click(function(e) {
//        //$(this).find(".second").slideToggle();
//		e.preventDefault();
//		$(this).find(".second").slideToggle(200);
//    });
	
	$("select").addClass("down_arrow_indicate");
	
	var win_width = $(window).width();
	
	$(".bracket_collar").prepend("<span></span>");
	$(".bracket_collar").prepend("<span></span>");
	$(".bracket_collar").prepend("<span></span>");
	$(".bracket_collar").prepend("<span></span>");
	
	$(".bracket_collar span:nth-child(1)").addClass("small_top_lft");
	$(".bracket_collar span:nth-child(2)").addClass("small_btm_lft");
	$(".bracket_collar span:nth-child(3)").addClass("small_top_ryt");
	$(".bracket_collar span:nth-child(4)").addClass("small_btm_ryt");

	$("header > nav > ul").addClass("main_menu");	
	$("header ul li ul").addClass("second");	
	$(".second").parent().addClass("down_tree");	
	$("header > nav > ul > li").addClass("m_op");
	
	var i=1;
	$('.m_op').each(function(){
		var temp='op'+i;
		$(this).attr('class',temp);
		++i;					
	});	
	
	//open sub-menu depending on h1
	
	var txtx = $("h1").text();	
	if(txtx === "Who we are"){
		$(".op3").find(".second").show();
		$(".op3 > a").click(function(e) {
			//$(this).find(".second").slideToggle();
			e.preventDefault();
			$(this).next().slideToggle(200);
		});		
	}
	else if(txtx === "What we do"){
		$(".op6").find(".second").show();
		$(".op6 > a").click(function(e) {
			//$(this).find(".second").slideToggle();
			e.preventDefault();
			$(this).next().slideToggle(200);
		});		
	}
		
	$(".main_menu").slimscroll({
	  height: '100%',
	  alwaysVisible: true,
	  railVisible: true,
	  size: '4px'
	});	
	
	var win_ht = $(window).height();
		
	if(win_ht<800){
		$(".main_menu").slimscroll({
		  height: '90vh',
		  alwaysVisible: true,
		  size: '4px'
		});
	}
	
	$(".desti_abt_details").slimscroll({
	  height: '255px',
	  size: '4px',
	  allowPageScroll: true,
	  alwaysVisible: true,
	});

	if(win_width>991){
		$(".places_thumb").slimscroll({
		  height: '403px',
		  alwaysVisible: true,
		  width: '420px',
		  allowPageScroll: true,
		  size: '4px'
		});
	}
	else{
		$(".places_thumb").slimscroll({
		  height: '290px',
		  alwaysVisible: true,
		  size: '4px',
		  allowPageScroll: true,
		  width: '295px',
		});
	}
	
	$(".menu_responsive_toggle").click(function() {
        $(this).toggleClass("menu_responsive_toggle_shift");
		$("header").toggleClass("show_header");
		
		$(".menu_sign").toggleClass("fa-arrow-left");
		$(".menu_sign").toggleClass("fa-bars");		
    });

	//homepage banner slider
	
	$(".slide").prepend("<div></div>");
	//slider	
	$(".slide").append("<span></span>");
	function initial_home_slider(){
		$(".slide").first().addClass("show_now_banner").removeClass("hide_now_banner").siblings().addClass("hide_now_banner").removeClass("show_now_banner");
	}
	
	function initial_home_slider_rev(){
		$(".slide").last().addClass("show_now_banner").removeClass("hide_now_banner").siblings().addClass("hide_now_banner").removeClass("show_now_banner");
	}
		
	//slide number
	var total = $(".slide").length;	
	$(".slide").each(function () {			
		var slide_num = $(this).index()+1;		
		$(this).find("span").text(slide_num +"/"+total);
	});

	//slider-next	
	
	initial_home_slider();
	
	function banner_next(){
		$(".show_now_banner").next().addClass("show_now_banner").removeClass("hide_now_banner");		
		$(".show_now_banner").last().prev().removeClass("show_now_banner").addClass("hide_now_banner");
		$(".show_now_banner").siblings().addClass("hide_now_banner");	
	}
	
	function banner_prev(){
		$(".show_now_banner").prev().addClass("show_now_banner").removeClass("hide_now_banner");			
		$(".show_now_banner").first().next().removeClass("show_now_banner").addClass("hide_now_banner");
		$(".show_now_banner").siblings().addClass("hide_now_banner");	
	}
		
	$(".nxt").click(function(e) {  
		e.preventDefault();      
		//banner_next();		
		if($(".show_now_banner").index() == total-1){			
			initial_home_slider();			
		}
		else{
			banner_next();
		}			
	});
			
	//slider-prev
	$(".prev").click(function(e) {  
		e.preventDefault();      
		//banner_prev();		
		if($(".show_now_banner").index() == 0){			
			initial_home_slider_rev();			
		}
		else{
			banner_prev();
		}		
	});	
	
	//destinations
	var d=1;
	$('.desti_buttons').find('.desti_thumb').each(function(){
		var temp='dest'+d;
		$(this).attr('id',temp);
		++d;					
	});
	
	var j=1;
	$('.desti_det').find('.desti_about').each(function(){
		var temp='dest'+j;
		$(this).attr('class',temp);
		++j;					
	});

	$(".desti_det").children().addClass("desti_about");	
	$(".desti_about").first().show().siblings().hide();	
	$(".desti_thumb").first().addClass("show_current");	
	$(".desti_thumb").prepend("<div></div>");	
	$(".desti_thumb div").append("<p></p>");	
	$(".desti_thumb div p").text("Viewing");	
	$(".desti_thumb div").append("<h3></h3>");	
	$(".desti_about").first().addClass("current_dest");

	var frst_nam = $(".current_dest h2").text();	
	$(".show_current h3").text(frst_nam);	
	
	$(".desti_thumb").click(function() {		
		$(this).addClass("show_current").siblings().removeClass("show_current");	        
		var aa = $(this).attr("id");		
		$("."+aa).slideDown(200).addClass("current_dest").siblings().slideUp(200).removeClass("current_dest");			
		var dest_name = $(".current_dest").find("h2").text();		
		$(".desti_thumb div h3").text(dest_name);			
    });

	//fav	
	var favt = $(".Favourites .abt_txt").height();	
	$(".fav_pic").css({"height":favt + "px"});
		
	//testimonial slider
	$(".test").first().addClass("show_now_test").siblings().addClass("hide_now_test");	
	$(".client span").removeClass("tap_num");	
			
		$(".show_now_test").show();
		$(".hide_now_test").hide();
		//slider-next		
		$(".test_nxt").click(function(e) {  
			e.preventDefault();      
			$(".show_now_test").next().addClass("show_now_test").removeClass("hide_now_test");		
			$(".show_now_test").last().prev().removeClass("show_now_test").addClass("hide_now_test");
			$(".show_now_test").siblings().addClass("hide_now_test");		
			$(".show_now_test").slideDown(200);
			$(".hide_now_test").slideUp(200);
		});
				
		//slider-prev
		$(".test_prev").click(function(e) {  
			e.preventDefault();
			$(".show_now_test").prev().addClass("show_now_test").removeClass("hide_now_test").next().removeClass("show_now_test").addClass("hide_now_test");
			$(".show_now_test").slideDown(200);
			$(".hide_now_test").slideUp(200);
		});
	
	$(".frame").each(function() {
        $(this).append("<div></div>");
		$(this).append("<span></span>");
		$(this).append("<span></span>");
		$(this).append("<span></span>");
		$(this).append("<span></span>");
    });
	
	$(".frame div").addClass("frm_blck");
	$(".frm_blck").next().addClass("frame_up");
	$(".frame_up").next().addClass("frame_ryt");
	$(".frame_ryt").next().addClass("frame_dwn");
	$(".frame_dwn").next().addClass("frame_lft");	
    
    //what we do page
    
    if(win_width>991){
        //var sec_ht = $(".what_we_do_page").innerHeight();
       // $(".what_we_do_page .frame").css({"height":sec_ht+"px"});
        
        $(".what_we_do_page .abt_txt").slimscroll({
            height: '500px',
            size: '4px',
            allowPageScroll: true,
            alwaysVisible: true,
        });    
        
        
    }
    
    
    
    
	//about us page ingredient slider	
	//$(".ingre_slider_pics img").addClass("ingre_slide");
	
	$(".ingre_slider_pics img").wrap("<div></div>");	
	$(".ingre_slider_pics div").addClass("ingre_slide");	
	$(".ingre_slide").append("<span></span>");
	
	$(".ingre_slider_line_holder_box h2 span").removeClass("small_top_lft");
	
	var total_ingre = $(".ingre_slide").length;	
	$(".ingre_slide").each(function () {			
		var slide_num = $(this).index()+1;		
		$(this).find("span").text(slide_num + "/" + total_ingre);
	});
	
	function first_ingre_load() {
		$(".ingre_slide").first().addClass("show_ingre").removeClass("hide_ingre").siblings().addClass("hide_ingre").removeClass("show_ingre");		
		$(".ingre_slide").last().addClass("restrt_ingre");		
		$(".ingre_slider_line_holder_box h2").addClass("ingre_line");			
		$(".ingre_line").first().addClass("show_ingre_line").removeClass("hide_ingre_line").siblings().addClass("hide_ingre_line").removeClass("show_ingre_line");
		$(".ingre_line").last().addClass("restrt_ingre_line");		
		$(".show_ingre_line").slideDown(500);
		$(".hide_ingre_line").slideUp(500);
	}
	
	function last_ingre_load() {
		$(".ingre_slide").last().addClass("show_ingre").removeClass("hide_ingre").siblings().addClass("hide_ingre").removeClass("show_ingre");					
		$(".ingre_line").last().addClass("show_ingre_line").removeClass("hide_ingre_line").siblings().addClass("hide_ingre_line").removeClass("show_ingre_line");	
		$(".show_ingre_line").slideDown(500);
		$(".hide_ingre_line").slideUp(500);
	}
	
	function next_ingre() {
		$(".show_ingre").next().addClass("show_ingre").removeClass("hide_ingre");
		$(".show_ingre").last().prev().removeClass("show_ingre").addClass("hide_ingre");		
		$(".show_ingre_line").next().addClass("show_ingre_line").removeClass("hide_ingre_line");
		$(".show_ingre_line").last().prev().removeClass("show_ingre_line").addClass("hide_ingre_line");		
		$(".show_ingre_line").slideDown(500);
		$(".hide_ingre_line").slideUp(500);
	}

	function prev_ingre() {
		$(".show_ingre").prev().addClass("show_ingre").removeClass("hide_ingre").next().removeClass("show_ingre").addClass("hide_ingre");		
		$(".show_ingre_line").prev().addClass("show_ingre_line").removeClass("hide_ingre_line").next().removeClass("show_ingre_line").addClass("hide_ingre_line");		
		$(".show_ingre_line").slideDown(500);
		$(".hide_ingre_line").slideUp(500);
	}
	
//	function restart(){
//		$(".ingre_slide").first().addClass("show_ingre").removeClass("hide_ingre").siblings().addClass("hide_ingre").removeClass("show_ingre");
//		$(".ingre_line").first().addClass("show_ingre_line").removeClass("hide_ingre_line").siblings().addClass("hide_ingre_line").removeClass("show_ingre_line");
//		alert("kluhyg");
//	}
	
	first_ingre_load();
	$(".nxt_ingre").click(function() {
				
		if($(".show_ingre").index() == total_ingre-1) {
			first_ingre_load();
		}
		else {
			next_ingre();
		}		
	});
	
	$(".prev_ingre").click(function(){
		//alert("s");
		
		if($(".show_ingre").index() == 0) {
			last_ingre_load();
		}
		else {
			prev_ingre();
		}	
		
		//prev_ingre();
	});	
		
	var history_intro = $(".history_intro").height();	
	$(".history_intro_pic div").height(history_intro);			
	$(".close_scroll").hide();
		
	$(".cont_scroll").click(function(){
		
		$(".timeline").slimscroll({
			height: '950px',
			size: '7px',
			width:'100%',
			allowPageScroll: true,
			color:'#fff',
			alwaysVisible: true,
		});				
	});
	
	if(win_width<767){

		$(".cont_scroll").click(function(){		
			$(".timeline").slimscroll({
				height: '480px',
			});				
		});	
		
		$('.close_scroll').click(function(){
			$('.timeline').slimScroll({
				destroy:true
			});
		
			var $elem = $('.timeline'),
			events = jQuery._data( $elem[0], "events" );		
			if (events) {
				jQuery._removeData( $elem[0], "events" );
			}	
		});			
	}
	
	$(".nav_scroll button").click(function(){
		$(this).hide().siblings().show();
	});	
	
	
	
	$('.close_scroll').click(function(){
		$('.timeline').slimScroll({
			destroy:true
		});	
		var $elem = $('.timeline'),
		events = jQuery._data( $elem[0], "events" );	
		if (events) {
			jQuery._removeData( $elem[0], "events" );
		}	
	});	
	
	if(win_width>991){

		$(".endrmnt_txt").slimscroll({
		  height: '450px',
		  size: '5px',
		  width:'100%',
		  allowPageScroll: true,
		  color:'#333',
		  alwaysVisible: true,
		});
		
		$(".history_txt").slimscroll({
		  height: '470px',
		  color:'#fff',
		  size:'6px',
		  allowPageScroll: true,
		  distance: '10px',
		  alwaysVisible: true
		});	
	}	

	var line_ht = $(".incident_holder").height()+80;	
	$(".timeline_blck").height(line_ht);		
	
	$(".incident:nth-child(odd)").addClass("arrow_right");
	
	$(".arrow_right").append("<span></span>");
	$(".arrow_right span").addClass("left_line");
	
	$(".left_line").each(function() {
        var e_ht = $(this).parent().height()+11;		
		$(this).css({"height":e_ht+"px"});
    });	
	
	$(".incident:nth-child(even)").addClass("arrow_left");
	$(".arrow_left").append("<span></span>");
	$(".arrow_left span").addClass("right_line");
	
	$(".right_line").each(function() {
        var e_ht = $(this).parent().height()+11;		
		$(this).css({"height":e_ht+"px"});
    });
	
	var hstry_intro_ht = $(".hstry_info").height();	
	$(".hstry_pic").height(hstry_intro_ht);
		
	//endorsment slider	
	$(".endrsmnt_slider").children().addClass("endrsment_slide");	
	$(".endrsment_slide").first().addClass("endrsment_slide_show").siblings().addClass("endrsment_slide_hide");	
	$(".endrsmnt_slider img").addClass("smooth");
		
	$(".endrsmnt_slider_nxt").click(function(){
		$(".endrsment_slide_show").next().addClass("endrsment_slide_show").removeClass("endrsment_slide_hide");
		$(".endrsment_slide_show").last().prev().removeClass("endrsment_slide_show").addClass("endrsment_slide_hide");
	});
	
	$(".endrsmnt_slider_prev").click(function(){
		$(".endrsment_slide_show").prev().addClass("endrsment_slide_show").removeClass("endrsment_slide_hide");
		$(".endrsment_slide_show").first().next().removeClass("endrsment_slide_show").addClass("endrsment_slide_hide");
	});	
		
	//team slider	
	var divs = $(".team_slider > .nomad");	
	if(win_width<991 && win_width>767){		
		var step = 2;
		for(var tt = 0; tt < divs.length; tt+=step) {
		  divs.slice(tt, tt+step).wrapAll("<div class='tm_slide'></div>");
		}		
				
		$(".tm_slide").first().show().addClass("show_team").siblings().hide().addClass("hide_team");
		
		$(".tm_slider_nxt").click(function(){
			$(".show_team").next().addClass("show_team").removeClass("hide_team");
			$(".show_team").last().prev().removeClass("show_team").addClass("hide_team");				
			$(".show_team").slideDown(100);
			$(".hide_team").slideUp(100);
		});
		
		$(".tm_slider_prev").click(function(){
			$(".show_team").prev().addClass("show_team").removeClass("hide_team");
			$(".show_team").first().next().removeClass("show_team").addClass("hide_team");				
			$(".show_team").slideDown(100);
			$(".hide_team").slideUp(100);
		});	
	}
	
	else if(win_width<768){		
		$(".nomad").wrapAll();		
		$(".nomad").first().show().addClass("show_team").siblings().hide().addClass("hide_team");
		
		$(".tm_slider_nxt").click(function(){
			$(".show_team").next().addClass("show_team").removeClass("hide_team");
			$(".show_team").last().prev().removeClass("show_team").addClass("hide_team");				
			$(".hide_team").hide();
			$(".show_team").show();
		});
		
		$(".tm_slider_prev").click(function(){			
			$(".show_team").prev().addClass("show_team").removeClass("hide_team");
			$(".show_team").first().next().removeClass("show_team").addClass("hide_team");
			$(".show_team").show();
			$(".hide_team").hide();
		});				
	}	
	
	else{		
		var steps = 3;		
		for(var tm = 0; tm < divs.length; tm+=steps) {
		  divs.slice(tm, tm+steps).wrapAll("<div class='tm_slide'></div>");
		}	
		
		$(".tm_slide").first().show().addClass("show_team").siblings().hide().addClass("hide_team");
		
		$(".tm_slider_nxt").click(function(){
			$(".show_team").next().addClass("show_team").removeClass("hide_team");
			$(".show_team").last().prev().removeClass("show_team").addClass("hide_team");			
			$(".show_team").slideDown(100);
			$(".hide_team").slideUp(100);
		});
		
		$(".tm_slider_prev").click(function(){
			$(".show_team").prev().addClass("show_team").removeClass("hide_team");
			$(".show_team").first().next().removeClass("show_team").addClass("hide_team");
			$(".show_team").slideDown(100);
			$(".hide_team").slideUp(100);
		});			
	}

	$(".styles_of_travels").hover(function() {
        $(this).toggleClass("big_resize").siblings().toggleClass("small_resize");		
    });
	
	$(".experimental_travels").hover(function() {
        $(this).toggleClass("big_resize").siblings().toggleClass("small_resize");
    });
	
	$(".we_do_points_tog").click(function(){
		$(this).next().slideToggle();
		$(this).parent().addClass("active_we_do").removeClass("inactive_we_do").siblings().addClass("inactive_we_do").removeClass("active_we_do");
		$(this).parent().siblings().find(".we_do_points_tog_close").hide();
		$(this).parent().siblings().find(".we_do_points_tog").show();
		$(".active_we_do .we_do_action_points").slideDown();
		$(".inactive_we_do .we_do_action_points").slideUp();
		$(this).hide().prev().show();
	});
	
	$(".we_do_points_tog_close").click(function(){
		$(this).hide();
		$(this).next().slideToggle();
		$(this).parent().removeClass("active_we_do").siblings().removeClass("inactive_we_do");
		$(this).next().next().slideUp();		
	});
		
	if(win_width<992){
		$(".we_do_action_points p").slimscroll({
			height:'120px',
			color:'#fff'
		});	
	}
	else{
		$(".we_do_action_points p").slimscroll({
			height:'290px',
			color:'#fff'
		});		
	}

	$(".quest").each(function() {
		$(this).find("img").wrapAll("<div></div>");
        $(this).find("h3").wrapAll("<div></div>");
		$(this).find("div").first().addClass("quest_img");
		$(".quest_img").next().addClass("quest_point");
    });
	
	function quest_slider_reset(){	
		$(".quest").first().addClass("show_quest").removeClass("hide_quest").siblings().addClass("hide_quest").removeClass("show_quest");
		$(".show_quest").slideDown(150);
		$(".hide_quest").slideUp(150);
	}
	
	function quest_slider_reset_prev(){	
		$(".quest").last().addClass("show_quest").removeClass("hide_quest").siblings().addClass("hide_quest").removeClass("show_quest");
		$(".show_quest").slideDown(150);
		$(".hide_quest").slideUp(150);
	}
	
	quest_slider_reset();
	
	function quest_next(){
		$(".show_quest").next().addClass("show_quest").removeClass("hide_quest");
		$(".show_quest").last().prev().removeClass("show_quest").addClass("hide_quest");		
		$(".show_quest").slideDown(150);
		$(".hide_quest").slideUp(150);
	}
	
	function quest_prev(){
		$(".show_quest").prev().addClass("show_quest").removeClass("hide_quest");
		$(".show_quest").first().next().removeClass("show_quest").addClass("hide_quest");		
		$(".show_quest").slideDown(150);
		$(".hide_quest").slideUp(150);
	}
	
	var total_quest = $(".quest").length;
	
	$(".quest_slider_next").click(function(){		
		if($(".show_quest").index() == total_quest-1){
			quest_slider_reset();
		}
		else{
			quest_next();
		}
	});
	
	$(".quest_slider_prev").click(function(){
		if($(".show_quest").index() == 0){
			quest_slider_reset_prev();
		}
		else{
			quest_prev();
		}		
	});

	$(".testimonial_block").hide();
	$(".testimonial_block").first().show();
	
	$(".select_testimonial").change(function(){		
		var test_val = $(this).val();		
		if(test_val==="Central America"){
			$(".central_amrica_test").show().siblings().hide();
		}
		else if(test_val==="South America"){
			$(".south_america_test").show().siblings().hide();
		}
		else if(test_val==="Other Trails"){
			$(".other_trails_test").show().siblings().hide();
		}
		else if(test_val==="The rest of the world"){
			$(".wrld_rest_test").show().siblings().hide();
		}		
	});
	
	$(".test_box").each(function() {
        $(this).children().wrapAll("<div></div>");
    });
	$(".test_box div").addClass("testimonial_txt");
	
	if(win_width>767){
		$(".testimonial_txt").slimscroll({
			  height: '420px',		  
			  allowPageScroll: true,
			  size:'5px',
			  color:'#333',
		});
	}
	else{
		
		$(".testimonial_txt").slimscroll({
			  height: '350px'
		});		
	}

	//how it works page	
	if(win_width>991){
		
		var hw_it_wrks = $(".how_it_works .abt_txt").height();
		$(".hwitwrks_rest_txt").css({"height":hw_it_wrks + "px"});		
	}
	
	//blueprint slider wrapper
	$(".blu_txt_wrapper").wrap("<div></div>");
	$(".blu_txt_wrapper").parent().addClass("blu_abt_slide_txt");
	$(".blu_abt_slide_txt").prepend("<span></span>");
	$(".blu_abt_slide_txt").prepend("<span></span>");
	$(".blu_abt_slide_txt span").first().addClass("small_top_lft");
	$(".blu_abt_slide_txt > .small_top_lft").next().addClass("small_top_ryt");

	$(".blu_slide").prepend("<span></span>");
	$(".blu_slide > span").addClass("mid_line");
	
	$(".blu_txt_wrapper p").addClass("blu_txt");
	$(".blu_header h5").addClass("blu_hd");
	
	var blp=1;
	$(".blu_txt_wrapper").find("p").each(function(){
		var temp='blu'+blp;
		$(this).addClass(temp);
		++blp;					
	});
	
	var blpico=1;
	$(".slider_icons_wrapper ul li").each(function(){
		var temp='blu'+blpico;
		$(this).attr('id',temp);
		++blpico;					
	});
	
	var wid = $(".slider_icons_wrapper ul li").width();	
	var lim = $(".slider_icons_wrapper ul li").length;
	var qwwq = lim+1;
	var ac = qwwq*wid;
	var limt = lim-6;
	var qwerty = limt*wid;
	
	$(".slider_icons_wrapper ul").css({"width":ac-60+"px"});
	var scr = $( ".slider_icons_wrapper" ).scrollLeft();
	
	$(".scr").text(scr);
	
	$(".blu_sml_next").click(function(){
		scr=scr+wid;
		//$( ".slider_icons_wrapper" ).scrollLeft(scr);
		$(".slider_icons_wrapper").animate({ scrollLeft: scr + "px" }, 100);
		$(".blu_sml_prev").attr("disabled",false);
		if(scr>qwerty){
			$(this).attr("disabled",true);			
		}		
		$(".scr").text(scr);
	});
	
	$(".blu_sml_prev").attr("disabled",true);
	
	$(".blu_sml_prev").click(function(){
		scr-=wid;
		//$( ".slider_icons_wrapper" ).scrollLeft(scr);
		$(".slider_icons_wrapper").animate({ scrollLeft: scr + "px" }, 100);
		
		if(scr===0){
			$(this).attr("disabled",true);
		}
		$(".blu_sml_next").attr("disabled",false);		
		$(".scr").text(scr);
	});

	var blpimg=1;
	$(".slide_pic").each(function(){
		var temp='blu'+blpimg;
		$(this).addClass(temp);
		++blpimg;					
	});
	
	var blphd=1;
	$(".blu_hd").each(function(){
		var temp='blu'+blphd;
		$(this).addClass(temp);
		++blphd;					
	});	
	
	$(".slide_pic").append("<div></div>");
	$(".slide_pic").append("<span></span>");
	
	$(".slide_pic span").addClass("blu_ind");
	$(".slide_pic div").addClass("blu_ovrly");
	
	$(".slide_pic").each(function() {
        var blu_index = $(this).index()+1;
		
		var total_blu = $(".slide_pic").length;
		$(this).find(".blu_ind").text(blu_index + "/" +total_blu);
		
    });
	
	var total_blu = $(".slide_pic").length;
	
	function blu_reset(){
		$(".slide_pic").first().show().addClass("blu_show").removeClass("blu_hidden").siblings().hide().addClass("blu_hidden").removeClass("blu_show");
		$(".blu_txt").first().show().addClass("blu_show").removeClass("blu_hidden").siblings().hide().addClass("blu_hidden").removeClass("blu_show");
		$(".blu_hd").first().show().addClass("blu_show").removeClass("blu_hidden").siblings().hide().addClass("blu_hidden").removeClass("blu_show");
		$(".slider_icons_wrapper ul li").first().addClass("active_button").siblings().removeClass("active_button");
		
		$(".blu_show").slideDown(200);
		$(".blu_hidden").slideUp(200);	
	}
	
	function blu_reset_prev(){
		$(".slide_pic").last().show().addClass("blu_show").removeClass("blu_hidden").siblings().hide().addClass("blu_hidden").removeClass("blu_show");
		$(".blu_txt").last().show().addClass("blu_show").removeClass("blu_hidden").siblings().hide().addClass("blu_hidden").removeClass("blu_show");
		$(".blu_hd").last().show().addClass("blu_show").removeClass("blu_hidden").siblings().hide().addClass("blu_hidden").removeClass("blu_show");
		$(".slider_icons_wrapper ul li").last().addClass("active_button").siblings().removeClass("active_button");
		
		$(".blu_show").slideDown(200);
		$(".blu_hidden").slideUp(200);	
	}
	
	blu_reset();
	
	function reactivate(){		
		$(".blu_nxt, .blu_prv").attr("disabled",true);		
		$(".slider_icons_wrapper ul li").addClass("no_click");
		setTimeout(function(){
			$(".blu_nxt, .blu_prv").attr("disabled",false);	
			$(".slider_icons_wrapper ul li").removeClass("no_click");		
		},200);
	}
	
	$(".slider_icons_wrapper ul li a").click(function(e){
		e.preventDefault();
	});	
	
	function blu_nxt(){
		$(".blu_show").next().addClass("blu_show").removeClass("blu_hidden").prev().removeClass("blu_show").addClass("blu_hidden");
		$(".blu_show").slideDown(200);
		$(".blu_hidden").slideUp(200);		
		reactivate();
	}
	
	function blu_prv(){
		$(".blu_show").prev().addClass("blu_show").removeClass("blu_hidden").next().removeClass("blu_show").addClass("blu_hidden");
		$(".blu_show").slideDown(200);
		$(".blu_hidden").slideUp(200);		
		reactivate();
	}
		
	$(".blu_nxt").click(function(){
		
		var qwe = $(".blu_show").index()+1;		
		$(".slider_icons_wrapper ul li:eq("+qwe+")").addClass("active_button").siblings().removeClass("active_button");
		
		if($(".blu_show").index() == total_blu-1){
			blu_reset();
		}
		else{
			blu_nxt();
		}
		
	});
	
	$(".blu_prv").click(function(){		
	
		var qwe = $(".blu_show").index()-1;		
		$(".slider_icons_wrapper ul li:eq("+qwe+")").addClass("active_button").siblings().removeClass("active_button");
	
		if($(".blu_show").index() == 0){
			blu_reset_prev();
		}
		else{
			blu_prv();
		}
		
	});
	
	$(".slider_icons_wrapper ul li").click(function(){		
		$(this).addClass("active_button").siblings().removeClass("active_button");
		
		var qwer = $(this).attr("id");		
		$("."+qwer).addClass("blu_show").removeClass("blu_hidden").siblings().addClass("blu_hidden").removeClass("blu_show");
		$(".blu_show").slideDown(200);
		$(".blu_hidden").slideUp(200);	
		reactivate();	
	});

	//gallery page
	
	var gall=1;
	$(".gallery").each(function(){
		var temp='gal'+gall;
		$(this).addClass(temp);
		++gall;					
	});
	
	var gallthmb=1;
	$(".gallery_thumb ul li").each(function(){
		var temp='gal'+gallthmb;
		$(this).attr("id", temp);
		++gallthmb;					
	});
	
	$(".gallery_thumb ul li a").click(function(e){
		e.preventDefault();
	});
	
	$(".gallery").hide();
	$(".gallery").first().show();
	
	$(".gallery_thumb ul li").click(function(){
		var gal = $(this).attr("id");		
		$("."+gal).slideDown().siblings().slideUp();		
	});

	$(".gallery").each(function() {
        $(this).prepend("<button></button>");
    });
	
	$(".gallery button").click(function(){
		$(this).parent().slideUp();
	});	
	
	//start planning page

	var val = $(this).val();

	$(".planning_form form select").click(function(){
		$(this).css({"color":"#555"});
	});
		
	$(".planning_form form select").change(function(){
		$(this).css({"color":"#555"});				
		if(val===""){
			$(this).css({"color":"#ccc"});
		}
		else{
			$(this).css({"color":"#555"});
		}		
	});
		
	$(".datepicker").datepicker({
		inline: true,
		changeMonth: true, 
		changeYear: true, 
		duration: 300, 
		minDate: 0
	});
	
	$(".datepicker").parent().addClass("date");
	
	if(win_width>991){
		
		var plan_form_ht = $(".planning_form").height();
		$(".planning_pic").height(plan_form_ht);	
	}

	var pl = 1;
	$(".places_thumb_opt").each(function() {
		var plc = 'place'+pl;
        $(this).attr("id",plc);
		++pl;		
		$(this).append("<span></span>");

		var main = $(this).find("h2").text();
		
		if(main === "Central America"){
			$(this).addClass("central_america");
		}
		else if(main === "South America"){
			$(this).addClass("south_america");
		}
		else if(main === "other trails"){
			$(this).addClass("other_trails");
		}
		else if(main === "special concoctions"){
			$(this).addClass("spcl_concoctions");
		}
		else if(main === "the rest of the world"){
			$(this).addClass("rest_of_world");
		}				
    });
	
	var plabt = 1;
	$(".places_abt_txt").children().each(function() {
        var plct = 'place'+plabt;
       // $(this).attr("class",plct);
	   $(this).addClass(plct);
		++plabt;
    });	

	var z = 1;
	$(".places_holder ul li").each(function() {
        var zzz = 'place_opt'+z;
       // $(this).attr("class",plct);
	   $(this).addClass(zzz);
		++z;
    });	

	function show_central_america() {		
		$(".places_thumb_holder").find(".central_america").wrapAll("<div class="+'show_central_america'+"></div>");
		$(".places_thumb_holder").find(".south_america").wrapAll("<div class="+'show_south_america'+"></div>");
		$(".places_thumb_holder").find(".other_trails").wrapAll("<div class="+'show_other_trails'+"></div>");
		$(".places_thumb_holder").find(".spcl_concoctions").wrapAll("<div class="+'show_spcl_concoctions'+"></div>");
		$(".places_thumb_holder").find(".rest_of_world").wrapAll("<div class="+'show_rest_of_world'+"></div>");
		
		$(".show_central_america").slideDown().siblings().slideUp();		
	}
	
	function show_south_america() {		
		$(".places_thumb_holder").find(".central_america").wrapAll("<div class="+'show_central_america'+"></div>");
		$(".places_thumb_holder").find(".south_america").wrapAll("<div class="+'show_south_america'+"></div>");
		$(".places_thumb_holder").find(".other_trails").wrapAll("<div class="+'show_other_trails'+"></div>");
		$(".places_thumb_holder").find(".spcl_concoctions").wrapAll("<div class="+'show_spcl_concoctions'+"></div>");
		$(".places_thumb_holder").find(".rest_of_world").wrapAll("<div class="+'show_rest_of_world'+"></div>");
		
		$(".show_south_america").slideDown().siblings().slideUp();		
	}
	
	function show_other_trails() {		
		$(".places_thumb_holder").find(".central_america").wrapAll("<div class="+'show_central_america'+"></div>");
		$(".places_thumb_holder").find(".south_america").wrapAll("<div class="+'show_south_america'+"></div>");
		$(".places_thumb_holder").find(".other_trails").wrapAll("<div class="+'show_other_trails'+"></div>");
		$(".places_thumb_holder").find(".spcl_concoctions").wrapAll("<div class="+'show_spcl_concoctions'+"></div>");
		$(".places_thumb_holder").find(".rest_of_world").wrapAll("<div class="+'show_rest_of_world'+"></div>");
		
		$(".show_other_trails").slideDown().siblings().slideUp();		
	}
	
	function show_spcl_concoctions() {		
		$(".places_thumb_holder").find(".central_america").wrapAll("<div class="+'show_central_america'+"></div>");
		$(".places_thumb_holder").find(".south_america").wrapAll("<div class="+'show_south_america'+"></div>");
		$(".places_thumb_holder").find(".other_trails").wrapAll("<div class="+'show_other_trails'+"></div>");
		$(".places_thumb_holder").find(".spcl_concoctions").wrapAll("<div class="+'show_spcl_concoctions'+"></div>");
		$(".places_thumb_holder").find(".rest_of_world").wrapAll("<div class="+'show_rest_of_world'+"></div>");
		
		$(".show_spcl_concoctions").slideDown().siblings().slideUp();		
	}
	
	function show_rest_of_world() {		
		$(".places_thumb_holder").find(".central_america").wrapAll("<div class="+'show_central_america'+"></div>");
		$(".places_thumb_holder").find(".south_america").wrapAll("<div class="+'show_south_america'+"></div>");
		$(".places_thumb_holder").find(".other_trails").wrapAll("<div class="+'show_other_trails'+"></div>");
		$(".places_thumb_holder").find(".spcl_concoctions").wrapAll("<div class="+'show_spcl_concoctions'+"></div>");
		$(".places_thumb_holder").find(".rest_of_world").wrapAll("<div class="+'show_rest_of_world'+"></div>");
		
		$(".show_rest_of_world").slideDown().siblings().slideUp();		
	}
	
	$(".place_opt1").click(function(e){
		e.preventDefault();	
		$(".places_thumb_holder").each(function() {
            $(this).slideDown();
			$(".show_rest_of_world, .show_spcl_concoctions, .show_other_trails, .show_south_america, .show_central_america").children().unwrap();
        });
	});
	
	$(".place_opt2").click(function(e){
		e.preventDefault();
		show_central_america();		
	});
	
	$(".place_opt3").click(function(e){
		e.preventDefault();
		show_south_america();
	});
	
	$(".place_opt4").click(function(e){
		e.preventDefault();
		show_other_trails();
	});
	
	$(".place_opt5").click(function(e){
		e.preventDefault();
		show_spcl_concoctions();
	});
	
	$(".place_opt6").click(function(e){
		e.preventDefault();
		show_rest_of_world();
	});

	$(".places_thumb_holder").slimScroll({
		height:'800px',
		allowPageScroll: true,
		color:'#fff',
		alwaysVisible: true,
		size: '4px'
	});
	
	$(".place_desc").hide();
	
	$(".places_thumb_opt").addClass("smooth");	
	
	$(".places_thumb_opt").click(function(){		
		var p = $(this).attr("id");		
		$('.'+p).slideDown().siblings().slideUp();
		$(this).addClass("active_place").siblings().removeClass("active_place");
	});
	
	$(".place_desc button").click(function(){
		$(this).parent().slideUp();
		$(".places_thumb_opt").removeClass("active_place");
	});

	$(".places_thumb_opt").children().addClass("smooth");
	
	$(".places_desc").each(function() {
        $(this).children().addClass("tp_desc");
		$(this).find("h3").addClass("topic inac");
		$(this).find("p").addClass("topic_txt");
		$(this).find("p").last().addClass("round_dn");
		$(this).find(".tp_desc").first().next().addClass("round_up");
		//$(this).find(".tp_desc").last().prev().addClass("round_dn");
		$(this).find(".round_up").next().show();
		$(".topic_txt").hide();
		$(this).find(".topic").first().addClass("active_topic").removeClass("inac");
    });	

	$(".active_topic").next().slideDown();		
	$(".inac").next().slideUp();
	$(".topic").click(function(){	
		$(this).toggleClass("active_topic inac").siblings("h3").addClass("inac").removeClass("active_topic");		
		$(".active_topic").next().slideDown();		
		$(".inac").next().slideUp();			
	});
		
	$(".places_holder_toggle").click(function(){		
		$(".places_holder ul").slideToggle();
	});
	
	if(win_width<991){
		$(".places_holder ul a").click(function(){
			$(".places_holder ul").slideUp();
		});
	}
	
	//terms li number
	$(".term_points ul > li").each(function() {
        
		$(this).prepend("<span></span>");
		
		var term_num = $(this).index()+1;
		
		$(this).find("span").text(term_num);
				
		
    });

	//gallerypage-fancybox
	$(".gal_thumb a").fancybox();

});

